/***************************************************************************
 *
 * This file is provided under a dual BSD/GPLv2 license.  When using or
 *   redistributing this file, you may do so under either license.
 * 
 *   GPL LICENSE SUMMARY
 * 
 *   Copyright(c) 2007-2024 Intel Corporation. All rights reserved.
 * 
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of version 2 of the GNU General Public License as
 *   published by the Free Software Foundation.
 * 
 *   This program is distributed in the hope that it will be useful, but
 *   WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   General Public License for more details.
 * 
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
 *   The full GNU General Public License is included in this distribution
 *   in the file called LICENSE.GPL.
 * 
 *   Contact Information:
 *   Intel Corporation
 * 
 *   BSD LICENSE
 * 
 *   Copyright(c) 2007-2024 Intel Corporation. All rights reserved.
 *   All rights reserved.
 * 
 *   Redistribution and use in source and binary forms, with or without
 *   modification, are permitted provided that the following conditions
 *   are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in
 *       the documentation and/or other materials provided with the
 *       distribution.
 *     * Neither the name of Intel Corporation nor the names of its
 *       contributors may be used to endorse or promote products derived
 *       from this software without specific prior written permission.
 * 
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *   OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * 
 *  version: QAT.L.4.28.0-00004
 *
 ****************************************************************************/
/****************************************************************************
 * @file qat_dbg_utils.cpp
 *
 * @description
 *        The file contains implementation of util functions used by
 *        QAT Debuggability report tool.
 *
 ****************************************************************************/
/* System headers */
#include <stdint.h>
#include <stdio.h>
#include <time.h>
#include <iostream>
#include <iomanip>

/* Project headers */
#include "qat_dbg_utils.h"
#include "OsalTypes.h"

/*
*******************************************************************************
* Private definitions
*******************************************************************************
*/
#define QAT_DBG_HEX_DUMP_BYTES_PER_LINE 16

/*
*******************************************************************************
* Public functions
*******************************************************************************
*/
void qatDbgGetIndent(std::string &dst, size_t indentLevel, char indentChar)
{
    size_t i;

    dst = "";
    for (i = 0; i < indentLevel; i++)
    {
        dst += indentChar;
    }
}

std::string qatDbgFormatTimestamp(Cpa64U ts)
{
    unsigned long long tsSec = ts / OSAL_BILLION;
    unsigned long long tsMsec = ts % OSAL_BILLION;
    time_t timestamp = (time_t)tsSec;
    struct tm tm = {0};
    char buff[64] = {0};
    size_t len = 0;

    if (NULL == gmtime_r(&timestamp, &tm))
    {
        snprintf(buff, sizeof(buff), "?");
    }
    else
    {
        len = strftime(buff, sizeof(buff), "%Y-%m-%d %H:%M:%S", &tm);
        snprintf(buff + len, sizeof(buff) - len, ".%llu", tsMsec);
    }

    return std::string(buff);
}

void qatDbgHexDump(const std::string &prefix, void *data, size_t dataLen)
{
    size_t i = 0;
    uint8_t *dataU8 = (uint8_t *)data;

    std::cout << prefix << std::setfill('0');
    for (i = 0; i < dataLen; i++)
    {
        std::cout << std::hex << std::setw(2) << (int)dataU8[i];
        if (!((i + 1) % QAT_DBG_HEX_DUMP_BYTES_PER_LINE))
        {
            std::cout << "\n" << prefix;
        }
        else
        {
            std::cout << " ";
        }
    }
    std::cout << std::dec << std::endl;
}