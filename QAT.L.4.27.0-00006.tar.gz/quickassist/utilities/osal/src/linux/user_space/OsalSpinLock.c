/**
 * @file OsalSpinLock.c (linux user space)
 *
 * @brief Implementation for spinlocks
 *
 *
 * @par
 *   BSD LICENSE
 * 
 *   Copyright(c) 2007-2024 Intel Corporation. All rights reserved.
 *   All rights reserved.
 * 
 *   Redistribution and use in source and binary forms, with or without
 *   modification, are permitted provided that the following conditions
 *   are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in
 *       the documentation and/or other materials provided with the
 *       distribution.
 *     * Neither the name of Intel Corporation nor the names of its
 *       contributors may be used to endorse or promote products derived
 *       from this software without specific prior written permission.
 * 
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *   OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 *  version: QAT.L.4.27.0-00006
 */

#include "Osal.h"

OSAL_PUBLIC OSAL_STATUS osalLockInit(OsalLock *slock, OsalLockType slockType)
{
#ifndef ICP_WITHOUT_THREAD
    OSAL_LOCAL_ENSURE(
        slock, "osalLockInit():   Null spinlock pointer", OSAL_FAIL);

    /* Spinlock type is ignored in case of Linux */
    return pthread_spin_init(slock, PTHREAD_PROCESS_PRIVATE) ? OSAL_FAIL
                                                             : OSAL_SUCCESS;
#else
    return OSAL_SUCCESS;
#endif
}

OSAL_PUBLIC OSAL_STATUS osalLock(OsalLock *slock)
{
#ifndef ICP_WITHOUT_THREAD
    OSAL_LOCAL_ENSURE(
        slock, "osalLockLock():   Null spinlock pointer", OSAL_FAIL);

    return pthread_spin_lock(slock) ? OSAL_FAIL : OSAL_SUCCESS;
#else
    return OSAL_SUCCESS;
#endif
}

OSAL_PUBLIC OSAL_STATUS osalUnlock(OsalLock *slock)
{
#ifndef ICP_WITHOUT_THREAD
    OSAL_LOCAL_ENSURE(
        slock, "osalLockUnlock():   Null spinlock pointer", OSAL_FAIL);

    return pthread_spin_unlock(slock) ? OSAL_FAIL : OSAL_SUCCESS;
#else
    return OSAL_SUCCESS;
#endif
}

OSAL_PUBLIC OSAL_STATUS osalLockDestroy(OsalLock *slock)
{
#ifndef ICP_WITHOUT_THREAD
    OSAL_LOCAL_ENSURE(
        slock, "osalLockDestroy():   Null spinlock pointer", OSAL_FAIL);

    return pthread_spin_destroy(slock) ? OSAL_FAIL : OSAL_SUCCESS;
#else
    return OSAL_SUCCESS;
#endif
}

OSAL_PUBLIC OSAL_STATUS osalLockBh(OsalLock *slock)
{
    return osalLock(slock);
}

OSAL_PUBLIC OSAL_STATUS osalUnlockBh(OsalLock *slock)
{
    return osalUnlock(slock);
}
