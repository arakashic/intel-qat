/****************************************************************************
 *
 * This file is provided under a dual BSD/GPLv2 license.  When using or
 *   redistributing this file, you may do so under either license.
 * 
 *   GPL LICENSE SUMMARY
 * 
 *   Copyright(c) 2007-2024 Intel Corporation. All rights reserved.
 * 
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of version 2 of the GNU General Public License as
 *   published by the Free Software Foundation.
 * 
 *   This program is distributed in the hope that it will be useful, but
 *   WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   General Public License for more details.
 * 
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
 *   The full GNU General Public License is included in this distribution
 *   in the file called LICENSE.GPL.
 * 
 *   Contact Information:
 *   Intel Corporation
 * 
 *   BSD LICENSE
 * 
 *   Copyright(c) 2007-2024 Intel Corporation. All rights reserved.
 *   All rights reserved.
 * 
 *   Redistribution and use in source and binary forms, with or without
 *   modification, are permitted provided that the following conditions
 *   are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in
 *       the documentation and/or other materials provided with the
 *       distribution.
 *     * Neither the name of Intel Corporation nor the names of its
 *       contributors may be used to endorse or promote products derived
 *       from this software without specific prior written permission.
 * 
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *   OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * 
 *  version: QAT.L.4.27.0-00006
 *
 ***************************************************************************/

/**
 *****************************************************************************
 * @file dc_err_sim.c
 *
 * @ingroup Dc_DataCompression
 *
 * @description
 *      Implementation of the Data Compression error inject operations.
 *
 *****************************************************************************/

#include "dc_err_sim.h"
#include "lac_log.h"

static Cpa8U num_dc_errors;
static CpaDcReqStatus dc_error;

CpaStatus dcSetNumError(Cpa8U numErrors, CpaDcReqStatus dcError)
{
    /* Excluding CPA_DC_INCOMPLETE_FILE_ERR as driver does not return this
     * error code */
    if ((dcError < CPA_DC_CRC_INTEG_ERR) || (dcError >= CPA_DC_OK) ||
        (CPA_DC_INCOMPLETE_FILE_ERR == dcError))
    {
        LAC_LOG_ERROR1("Unsupported ErrorType %d\n", dcError);
        return CPA_STATUS_FAIL;
    }
    num_dc_errors = numErrors;
    dc_error = dcError;

    return CPA_STATUS_SUCCESS;
}

CpaBoolean dcErrorSimEnabled(void)
{
    if (num_dc_errors > 0)
    {
        return CPA_TRUE;
    }
    else
    {
        return CPA_FALSE;
    }
}

CpaDcReqStatus dcGetErrors(void)
{
    CpaDcReqStatus error = 0;

    if (DC_ERROR_SIM == num_dc_errors)
    {
        error = dc_error;
    }
    else if (num_dc_errors > 0 && num_dc_errors <= DC_ERROR_SIM_MAX)
    {
        num_dc_errors--;
        error = dc_error;
    }
    else
    {
        error = 0;
    }
    return error;
}
